<nav class="navbar navbar-expand-lg bg-transparent">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">LOGO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link fw-500" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-500" href="index.php#course">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-500" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-500" href="contactus.php">Contact Us</a>
                </li>
            </ul>
        </div>
    </div>
</nav>